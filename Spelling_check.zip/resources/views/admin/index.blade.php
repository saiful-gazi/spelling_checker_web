
@extends('layouts/app')

@section('content')
<div class="container">
  <div class="row">
    <div class="col-6 offset-3">
      <div class="card">
        <div class="card-header bg-success">
           Add Word Name
        </div>
        @if(session('status'))
        <div class="alert alert-success">
              {{session('status')}}
        </div>
        @endif
        @if($errors->all())

        <div class="alert alert-danger">
          @foreach($errors->all() as $error)
          <li>{{$error}}</li>

            @endforeach
        </div>

        @endif

        <div class="card-body">
          <form action="{{url('/add/word/insert')}}" method="post">
            @csrf
            <div class="form-group">
              <label>Word Name</label>
              <input type="text" class="form-control" placeholder="Enter Word Name" name="word">
            </div>
            <button type="submit" class="btn btn-success">Add Word</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
