


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-6 offset-3">
      <div class="card">
        <div class="card-header bg-success">
           Add Word Name
        </div>
        <?php if(session('status')): ?>
        <div class="alert alert-success">
              <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <?php if($errors->all()): ?>

        <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php endif; ?>

        <div class="card-body">
          <form action="<?php echo e(url('/add/word/insert')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label>Word Name</label>
              <input type="text" class="form-control" placeholder="Enter Word Name" name="word">
            </div>
            <button type="submit" class="btn btn-success">Add Word</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\multiple\resources\views/admin/index.blade.php ENDPATH**/ ?>