<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Word;

class WordController extends Controller
{
  function addwordinsert(Request $request){
      $request->validate([
        'word'=>'required',
      ]);
      Word::insert([
        'word'=>$request->word,

      ]);
      return back()->with('status','Word Inserted Successfully!');
    }
}
